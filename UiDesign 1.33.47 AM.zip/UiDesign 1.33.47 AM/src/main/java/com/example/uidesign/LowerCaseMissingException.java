package com.example.uidesign;


public class LowerCaseMissingException extends PasswordException {
    public LowerCaseMissingException(String errorMessage) {
        super(errorMessage);

    }
}

