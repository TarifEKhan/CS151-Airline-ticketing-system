package com.example.uidesign;


public class NumberCharacterMissingException extends PasswordException {
    public NumberCharacterMissingException(String errorMessage) {
        super(errorMessage);
    }
}

