package com.example.uidesign;


public class PasswordException extends Exception {
    public PasswordException(String errorMessage) {
        super(errorMessage);
    }










}
