package com.example.uidesign;

public class SpecialCharacterMissingException extends Throwable {
    public SpecialCharacterMissingException(String errorMessage) {
        super(errorMessage);
    }

}
