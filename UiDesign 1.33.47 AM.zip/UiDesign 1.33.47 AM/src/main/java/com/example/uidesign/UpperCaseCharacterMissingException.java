package com.example.uidesign;

public class UpperCaseCharacterMissingException extends Throwable {


    public UpperCaseCharacterMissingException(String errorMessage) {
        super(errorMessage);

    }



}
