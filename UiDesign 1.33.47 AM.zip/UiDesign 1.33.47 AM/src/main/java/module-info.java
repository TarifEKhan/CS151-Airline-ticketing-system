module UiDesign {
    requires javafx.controls;
    requires javafx.fxml;
    opens com.example.uidesign; // Replace with your actual package name
}
